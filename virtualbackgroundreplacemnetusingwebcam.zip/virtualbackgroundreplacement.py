import cv2
import torch
import numpy as np
from torchvision.models.segmentation import deeplabv3_mobilenet_v3_large, DeepLabV3_MobileNet_V3_Large_Weights
from PIL import Image

weights = DeepLabV3_MobileNet_V3_Large_Weights.DEFAULT
model = deeplabv3_mobilenet_v3_large(weights=weights).eval()
bg_img = cv2.imread("background.jpg")

transform = weights.transforms()

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    small_frame = cv2.resize(frame, (693, 520))
    h, w, _ = small_frame.shape
    bg_resized = cv2.resize(bg_img, (w, h))

    pil_image = Image.fromarray(cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB))
    input_tensor = transform(pil_image).unsqueeze(0)

    with torch.no_grad():
        output = model(input_tensor)['out'][0]
    mask = output.argmax(0).byte().cpu().numpy()

    person_mask = (mask == 15).astype(np.uint8)
    person_mask = cv2.GaussianBlur(person_mask.astype(np.float32), (15, 15), 0)
    person_mask = np.expand_dims(person_mask, axis=2)

    blended = small_frame * person_mask + bg_resized * (1 - person_mask)
    blended = blended.astype(np.uint8)
    blended_display = cv2.resize(blended, (640, 480))

    cv2.imshow('Virtual Background', blended_display)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()